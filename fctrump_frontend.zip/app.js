let signer;
let contract;

async function connectWallet() {
  if (!window.ethereum) {
    alert("MetaMask not detected");
    return;
  }

  const provider = new ethers.providers.Web3Provider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  signer = provider.getSigner();

  const address = await signer.getAddress();
  document.getElementById("walletAddress").innerText = `Connected: ${address}`;

  contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
}

async function createVote() {
  const question = document.getElementById("question").value;
  const options = document.getElementById("options").value.split(",");
  const tx = await contract.createVote(question, options);
  await tx.wait();
  alert("Vote created!");
}

async function vote() {
  const voteId = document.getElementById("voteId").value;
  const optionIndex = document.getElementById("optionIndex").value;
  const tx = await contract.vote(voteId, optionIndex);
  await tx.wait();
  alert("Voted!");
}

async function getResults() {
  const id = document.getElementById("resultVoteId").value;
  const results = await contract.getVoteResults(id);
  document.getElementById("results").innerText =
    `Question: ${results[0]}\nOptions: ${results[1]}\nVotes: ${results[2]}`;
}
